import React from 'react';

export const Account = () => {
  return <h2>Account</h2>;
};

export default Account;
