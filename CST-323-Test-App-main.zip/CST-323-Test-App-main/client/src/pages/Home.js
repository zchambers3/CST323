import React from 'react';
import { Row, Col, Container } from 'react-bootstrap';

export const Home = () => {
  return (
    <Container>
      <Row>
        <Col>Stuff</Col>
        <Col>More Stuff</Col>
      </Row>
      <Row>
        <Col>Stuff</Col>
        <Col>More Stuff</Col>
      </Row>
    </Container>
  );
};

export default Home;
